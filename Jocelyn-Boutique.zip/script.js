// Charger et afficher les produits depuis produits.json
document.addEventListener("DOMContentLoaded", () => {
  const liste = document.getElementById("liste-produits");
  const detailSection = document.getElementById("detail-produit");
  const panierIcon = document.getElementById("panierIcon");

  if (liste) {
    fetch("produits.json")
      .then(response => response.json())
      .then(data => {
        data.forEach((produit, index) => {
          const div = document.createElement("div");
          div.className = "product";
          div.setAttribute("data-category", produit.categorie);

          div.innerHTML = `
            <img src="${produit.image}" alt="${produit.nom}" />
            <h4>${produit.nom}</h4>
            <p>${produit.prix} €</p>
            <button onclick="ajouterAuPanier('${produit.nom}', ${produit.prix})">Ajouter au panier</button>
            <button onclick="afficherDetail(${index})">Détail</button>
          `;

          liste.appendChild(div);
        });

        // Stocker les produits dans une variable globale
        window._produits = data;

        // Appliquer filtre via URL ?cat=
        const cat = getParamURL("cat");
        if (cat) filtrerProduits(cat);
      })
      .catch(err => {
        console.error("Erreur chargement produits :", err);
      });
  }

  // Fermer détail
  const closeBtn = document.getElementById("fermer-detail");
  if (closeBtn) {
    closeBtn.addEventListener("click", () => {
      detailSection.style.display = "none";
    });
  }

  // Mini panier toggle
  if (panierIcon) {
    panierIcon.addEventListener("click", () => {
      document.getElementById("miniPanier").classList.toggle("hidden");
      afficherMiniPanier();
    });
  }

  afficherPanier();
});

// Fonction pour filtrer dynamiquement les produits
function filtrerProduits(categorie) {
  const produits = document.querySelectorAll(".product");
  produits.forEach(produit => {
    const cat = produit.getAttribute("data-category");
    produit.style.display = (categorie === "all" || cat === categorie) ? "block" : "none";
  });
}

// Obtenir une valeur dans l’URL ?cat=...
function getParamURL(nom) {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get(nom);
}

// VARIABLES PANIER
let panier = JSON.parse(localStorage.getItem("panier")) || [];

// Ajouter au panier
function ajouterAuPanier(nom, prix) {
  panier.push({ nom, prix });
  localStorage.setItem("panier", JSON.stringify(panier));
  afficherMiniPanier();
  alert(`${nom} ajouté au panier.`);
}

// Affichage panier dans mini div
function afficherMiniPanier() {
  const miniPanier = document.getElementById("miniPanier");
  miniPanier.innerHTML = "";
  let total = 0;

  if (panier.length === 0) {
    miniPanier.innerHTML = "<p>Panier vide</p>";
    return;
  }

  panier.forEach((item, index) => {
    const ligne = document.createElement("div");
    ligne.className = "ligne-panier";
    ligne.innerHTML = `
      ${item.nom} - ${item.prix} €
      <button onclick="supprimerDuPanier(${index})">❌</button>
    `;
    miniPanier.appendChild(ligne);
    total += item.prix;
  });

  const totalDiv = document.createElement("div");
  totalDiv.innerHTML = `<strong>Total : ${total} €</strong>`;
  miniPanier.appendChild(totalDiv);
}

// Supprimer produit panier
function supprimerDuPanier(index) {
  panier.splice(index, 1);
  localStorage.setItem("panier", JSON.stringify(panier));
  afficherMiniPanier();
}

// Afficher les détails d’un produit
function afficherDetail(index) {
  const produit = window._produits[index];
  if (!produit) return;

  document.getElementById("detail-nom").textContent = produit.nom;
  document.getElementById("detail-image").src = produit.image;
  document.getElementById("detail-description").textContent = produit.description;
  document.getElementById("detail-prix").textContent = produit.prix;

  document.getElementById("detail-produit").style.display = "block";
}
